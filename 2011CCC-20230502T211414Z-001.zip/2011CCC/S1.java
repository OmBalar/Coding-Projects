import java.util.*;
class Main{
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);

        int N = input.nextInt();

        ArrayList<String> student = new ArrayList<String>();
        ArrayList<String> teacher = new ArrayList<String>();

        int marks = 0;

        for(int i = 0; i < N; i++){
            student.add(input.next());
        }
        for(int i = 0; i < N; i++){
            teacher.add(input.next());
        }
        
        for(int i = 0; i < N; i++){
            if(student.get(i).equals(teacher.get(i))){
                marks++;
            }
        }

        System.out.println(marks);
    }
}